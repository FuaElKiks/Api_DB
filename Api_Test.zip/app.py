from flask import Flask, request, render_template, redirect, url_for, flash, session
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'clave-secreta'
app.config['JWT_SECRET_KEY'] = 'super-secret-key'
jwt = JWTManager(app)


db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="TU CONTRASEÑA DE MYSQL WORKBENCH ROOT", #IMPORTANTE 
    database="usuarios_imc"
)

cursor = db.cursor()

# Crear tabla si no existe
cursor.execute()
db.commit()

def calcular_imc(peso, altura):
    """Función para calcular el IMC"""
    return round(peso / (altura ** 2), 2)

@app.route('/')
def index():
    return render_template('index.html')



@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        password_hash = generate_password_hash(password)

        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        if cursor.fetchone():
            flash("Ese usuario ya existe.")
            return redirect(url_for('register'))

        cursor.execute("INSERT INTO users (username, password_hash) VALUES (%s, %s)", (username, password_hash))
        db.commit()
        flash("Usuario registrado con éxito.")
        return redirect(url_for('login')) 

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cursor.execute("SELECT password_hash FROM users WHERE username = %s", (username,))
        result = cursor.fetchone()

        if not result or not check_password_hash(result[0], password):
            flash("Credenciales inválidas")
            return redirect(url_for('login'))

        session['username'] = username
        flash("Inicio de sesión exitoso")
        return redirect(url_for('user_data'))

    return render_template('login.html')



@app.route('/protected', methods=['GET'])
@jwt_required()
def protected():
    current_user = get_jwt_identity()
    return render_template('protected.html', user=current_user)




@app.route('/user_data', methods=['GET', 'POST'])
def user_data():
    if 'username' not in session:
        flash("Debes iniciar sesión primero.")
        return redirect(url_for('login'))

    username = session['username']

    if request.method == 'POST':
        peso = float(request.form['peso'])
        altura = float(request.form['altura'])
        edad = int(request.form['edad'])

        imc = calcular_imc(peso, altura)

        cursor.execute("""
            UPDATE users
            SET peso = %s, altura = %s, edad = %s, imc = %s
            WHERE username = %s
        """, (peso, altura, edad, imc, username))
        db.commit()

        # Mensaje personalizado según el IMC
        if imc < 18.5:
            mensaje = f"Tu IMC es {imc}. Estás por debajo del peso saludable."
        elif 18.5 <= imc < 25:
            mensaje = f"Tu IMC es {imc}. ¡Estás en un rango saludable!"
        elif 25 <= imc < 30:
            mensaje = f"Tu IMC es {imc}. Tienes sobrepeso. Considera mejorar tus hábitos."
        elif 30 <= imc < 35:
            mensaje = f"Tu IMC es {imc}. Tienes obesidad grado I. Es recomendable consultar a un especialista."
        elif 35 <= imc < 40:
            mensaje = f"Tu IMC es {imc}. Tienes obesidad grado II. Es importante tomar acción."
        else:
            mensaje = f"Tu IMC es {imc}. Tienes obesidad grado III. Busca apoyo médico especializado."

        flash(mensaje)
        return redirect(url_for('user_data'))

    return render_template('user_data.html')




if __name__ == "__main__":
    app.run(debug=True)
